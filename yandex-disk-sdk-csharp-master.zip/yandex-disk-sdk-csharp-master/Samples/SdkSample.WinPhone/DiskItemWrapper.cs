﻿using Disk.SDK;

namespace SdkSample.WinPhone
{
    public class DiskItemWrapper
    {
        public DiskItemInfo DiskItem { get; set; }

        public bool IsSelected { get; set; }
    }
}